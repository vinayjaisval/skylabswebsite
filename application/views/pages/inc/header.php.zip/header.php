<?php $this->session->set_userdata('referred_from', current_url()); ?>

<!DOCTYPE html>
<html lang="en">

<head>
   <!-- Basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="keywords" content="<?= $meta_keyword; ?>">
   <meta name="description" content="<?= $meta_description; ?>">
   <title> <?= $meta_title; ?> </title>
   <meta name="author" content="">

   <link rel="shortcut icon" href="<?= base_url('assets/admin/uploads/' . $favicon) ?>" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <meta name="google-site-verification" content="lAKdcq2vQnMEozUU3Ohqy9fXfo7SS-5WG-q3x7eZ2KA" />
   <!--<meta name="google-site-verification" content="pCVWIRVrTiDpZLC--Gp23uUDwRFv7_H_ik1v1TT4nuQ" />-->
   <!-- Mobile Metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">
   <!-- Web Fonts  -->
   <link href="https://fonts.googleapis.com/css?family=Montserrat:100,300,400,500,600,700,900%7COpen+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">
   <!-- Vendor CSS -->
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/bootstrap/css/bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/animate/animate.min.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/linear-icons/css/linear-icons.min.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/owl.carousel/assets/owl.carousel.min.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/owl.carousel/assets/owl.theme.default.min.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/magnific-popup/magnific-popup.min.css">
   <!-- Theme CSS -->
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/theme.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/theme-elements.css">

   <!-- Current Page CSS -->
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/rs-plugin/css/settings.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/rs-plugin/css/layers.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>vendor/rs-plugin/css/navigation.css">
   <!-- Skin CSS -->
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/skins/default.css">
   <script src="master/style-switcher/style.switcher.localstorage.js"></script>
   <!-- Theme Custom CSS -->
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/custom.css">
   <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>style.css">



   <!-- Head Libs -->
   <script src="<?php echo base_url('assets/'); ?>vendor/modernizr/modernizr.min.js"></script>
   <!-- Google Tag Manager -->
   <script>
      (function(w, d, s, l, i) {
         w[l] = w[l] || [];
         w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
         });
         var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
         j.async = true;
         j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
         f.parentNode.insertBefore(j, f);
      })(window, document, 'script', 'dataLayer', 'GTM-PFFWTQ3B');
   </script>
   <!-- End Google Tag Manager -->
   <style>
      .overlay {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 0%;
         background: rgba(0, 0, 0, 0.5);
         backdrop-filter: blur(8px);
         display: flex;
         justify-content: center;
         align-items: center;
         visibility: visible;
         opacity: 1;
         transition: opacity 0.3s ease, visibility 0.3s ease;
         z-index: 999;
      }

      .popup {
         position: relative;
         background: white;
         padding: 20px;
         border-radius: 10px;
         text-align: center;
         /* width: 300px; */
         box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
         transition: 0.3s ease-in-out;

      }

      .popup img {
         width: 100%;
         border-radius: 10px;
         margin-top: 700px;

      }

      .close-btn {
         position: absolute;
         top: 718px;
         right: 10px;
         background: red;
         color: white;
         border: none;
         border-radius: 50%;
         width: 25px;
         height: 25px;
         font-size: 16px;
         display: flex;
         justify-content: center;
         align-items: center;
         cursor: pointer;
      }

      .hidden {
         visibility: hidden;
         opacity: 0;
      }
   </style>
</head>

<body>


   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-119007924-1"></script>
   <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
         dataLayer.push(arguments);
      }
      gtag('js', new Date());

      gtag('config', 'UA-119007924-1');
   </script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">


   <div class="body">
      <header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 120}">
         <div class="header-body">

            <div class="header-top header-top-colored">
               <div class="header-top-container container">
                  <div class="header-row">
                     <div class="header-column justify-content-start" style="max-width: calc(100% - 140px)">
                        <marquee class="color-black"><b>Exciting news! </b>Skylabs has gone global, with a presence in Bharat, Mauritius, Dubai, and is supercharging businesses worldwide, including Russia and Korea! #SkylabsGlobalExpansion #BusinessBoost #ConnectingWorld</marquee>
                        <!--<marquee class="color-black"><b>Exciting news! </b>VITIB 2025 Business Connect – 5th March | Network & explore opportunities with West Africa’s leading tech & business hub!</marquee>-->


                     </div>
                     <div class="header-column header-columnokh77 justify-content-end">


                        <div class="dropdown ditem rr">
                           <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                              <i class="fa fa-globe" aria-hidden="true"></i> &nbsp; Change Lang
                           </button>

                           <div class="dropdown-menu">
                              <?php
                              $statement = $this->db->query("SELECT * FROM lanuage WHERE 1 AND active = 'Active'");
                              foreach ($statement->result() as $row) {
                              ?>
                                 <a class="dropdown-item tt" href="<?= $row->link; ?>">
                                    <img src="<?php echo base_url('assets/admin/uploads/' . $row->photo); ?>"> <?= $row->name; ?>
                                 </a>
                              <?php } ?>
                           </div>
                        </div>
                        <?php
                        $statementAbt = $this->db->query("SELECT * FROM tbl_settings_contact WHERE 1");
                        foreach ($statementAbt->result() as $rowA) {
                        ?>
                           <ul class="header-top-social-icons social-icons social-icons-transparent  ">
                              <li class="social-icons-facebook">
                                 <a href="<?= $rowA->contact20; ?>" target="_blank" title="Facebook"> <i class="fab fa-facebook-square"></i> </a>
                              </li>
                              <li class="social-icons-twitter">
                                 <a href="<?= $rowA->contact21; ?>" target="_blank" title="Twitter"><i class="fab fa-twitter-square"></i></a>
                              </li>
                              <li class="social-icons-linkedin">
                                 <a href="<?= $rowA->contact22; ?>" target="_blank" title="Linkedin"><i class="fab fa-linkedin-square"></i></a>
                              </li>

                              <li class="social-icons-instagram">
                                 <a href="<?= $rowA->contact23; ?>" target="_blank" title="Instragram"><i class="fab fa-youtube-square"></i></a>
                              </li>
                           </ul>
                        <?php } ?>
                     </div>
                  </div>
               </div>
            </div>

            <div class="header-container ">
               <div class="container header-row">
                  <div class="header-column justify-content-start">
                     <div class="header-logo">
                        <a href="<?php echo base_url(); ?>">
                           <?php if (!empty($logo)) {
                           ?>
                              <img alt="SkyLabs Solution" src="<?= base_url('assets/admin/uploads/' . $logo) ?>" class="sky-logo width-a">
                           <?php } else { ?>
                              <img alt="SkyLabs Solution" src="<?= base_url('assets/admin/uploads/logo2.png') ?>" class="sky-logo width-a">
                           <?php } ?>
                        </a>
                     </div>
                  </div>
                  <div class="header-column header-columnokh77 justify-content-end" style="width:205px">
                     <div class="header-nav">
                        <div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1">
                           <nav class="collapse">
                              <ul class="nav flex-column flex-lg-row" id="mainNav">
                                 <li class="">
                                    <a class="active" href=""> Home</a>
                                 </li>
                                 <!-- <li class="dropdown dropdown-mega">
                                    <a class="dropdown-item dropdown-toggle" href="https://www.skylabstech.com/services.html">
                                       Services <i class="menu-arrow"></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                       <li>
                                          <div class="dropdown-mega-content">
                                             <div class="row">

                                                <div class="dd">
                                                   <a class="dropdown-item " href="http://localhost/skylabstech/gis-solution.html"> <span class="dropdown-mega-sub-title">
                                                         <img src="http://localhost/skylabstech/assets/admin/uploads/icon-gis-consulting.png" style="width:40px"> <span style="color:black"> GIS Solution </span></span></a>
                                                   <ul class="dropdown-mega-sub-nav">
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/remote-sensing.html">Remote Sensing</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/sky-gis.html">Sky GIS</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/drone-solutions.html">Skylabs - Drone Solutions</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/lmis.html">Skylabs - LMIS</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/lmis.html">Skylabs - LMIS</a></li>

                                                   </ul>
                                                </div>
                                                <div class="dd">
                                                   <a class="dropdown-item " href="http://localhost/skylabstech/telematics-solution.html"> <span class="dropdown-mega-sub-title">
                                                         <img src="http://localhost/skylabstech/assets/admin/uploads/icon-gis-consulting1.png" style="width:40px"> <span style="color:black"> Telematics Solution </span></span></a>
                                                   <ul class="dropdown-mega-sub-nav">
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/fleet-management-system.html">Fleet Management System</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/emergency-response-system.html">Skylabs - Emergency Response System</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/skylabs-mdvr-solution.html">Skylabs MDVR Solution</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/depot-management-system.html">Skylabs - Depot Management System</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/video-telematics-solution.html">Video Telematics Solution</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/dash-cam.html">Dash Cam</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/driver-monitoring-solution-adasdms.html">Driver Monitoring Solution (ADAS/DMS)</a></li>

                                                   </ul>
                                                </div>
                                                <div class="dd">
                                                   <a class="dropdown-item " href="http://localhost/skylabstech/smart-city-solution.html"> <span class="dropdown-mega-sub-title">
                                                         <img src="http://localhost/skylabstech/assets/admin/uploads/car-icon-9.png" style="width:40px"> <span style="color:black"> Smart City Solution </span></span></a>
                                                   <ul class="dropdown-mega-sub-nav">
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/sky-itms-solution.html">Sky ITMS Solution</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/automated-fare-collection-system.html">Skylabs - Automated Fare Collection System</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/solid-waste-management-and-monitoring-system.html">Skylabs - Solid Waste Management and Monitoring System</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/rfid-technology.html">Skylabs - RFID (Radio Frequency Identification Detector) </a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/gate-automation-solution.html">Skylabs - Gate Automation Solution</a></li>

                                                   </ul>
                                                </div>
                                                <div class="dd">
                                                   <a class="dropdown-item " href="http://localhost/skylabstech/manpower-consulting.html"> <span class="dropdown-mega-sub-title">
                                                         <img src="http://localhost/skylabstech/assets/admin/uploads/2726638.png" style="width:40px"> <span style="color:black"> Skylabs - EV Solutions </span></span></a>
                                                   <ul class="dropdown-mega-sub-nav">
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/bms-battery-management-system.html">Battery Management System</a></li>
                                                      <li><a class="dropdown-item " href="http://localhost/skylabstech/iot-for-electric-charging-station.html">IOT for Electric Charging Station</a></li>

                                                   </ul>
                                                </div>
                                                <div class="dd">
                                                   <a class="dropdown-item " href="http://localhost/skylabstech/smart-city-solution.html"> <span class="dropdown-mega-sub-title">
                                                         <img src="http://localhost/skylabstech/assets/admin/uploads/car-icon-9.png" style="width:40px"> <span style="color:black"> Cyber Security </span></span></a>
                                                   <ul class="dropdown-mega-sub-nav sub-nav-nav">
                                                      <li><a class="dropdown-item" href="<?= base_url('Home/syber'); ?>"> <span style="color:black" class=""> CM-as-a-Service</span>
                                                            <p>Compliance-Management -As-A-Service</p>
                                                         </a></li>
                                                      <li><a class="dropdown-item" href="<?= base_url('Home/mdmservice'); ?>"> <span style="color:black" class=""> MDM-as-a-Service</span>
                                                            <p>MDM-And-MTD-As-A-Service</p>
                                                         </a></li>
                                                      <li><a class="dropdown-item" href="<?= base_url('Home/patch'); ?>"> <span style="color:black" class=""> Patch Management</span>
                                                            <p>Patch Management Services</p>
                                                         </a></li>
                                                      <li><a class="dropdown-item" href="<?= base_url('Home/sosservice'); ?>"> <span style="color:black" class=""> SOC-as-a-Service</span>
                                                            <p>SIEM Based 24x7 SOC Monitoring </p>
                                                         </a></li>

                                                   </ul>
                                                </div>
                                             </div>
                                          </div>
                                       </li>
                                    </ul>
                                 </li> -->

                                 <?php
                                 $fQuery = $this->db->query("SELECT * FROM tbl_menu WHERE menu_parent=0 ORDER BY menu_order ASC");
                                 foreach ($fQuery->result() as $fRow) {
                                    $SubQuery = $this->db->query("SELECT * FROM tbl_menu WHERE menu_parent='" . $fRow->id . "' ORDER BY menu_order ASC");
                                    if ($fRow->menu_type == 'Page') {
                                       $fQuerySub = $this->db->query("SELECT * FROM tbl_page WHERE id= {$fRow->page_id} ORDER BY id ASC");
                                       foreach ($fQuerySub->result() as $fRowSub) {
                                          $menuName = $fRowSub->page_name;
                                          $menuUrl = base_url($fRowSub->page_slug) . '.html';
                                       }
                                    } else {
                                       $menuName = $fRow->menu_name;
                                       $menuUrl = $fRow->menu_url;
                                    }

                                    //Get For Sub Sub Menus ---
                                    $SubSubQuery = "";
                                    if ($SubQuery->num_rows() > 0) {
                                       foreach ($SubQuery->result() as $fRow1) {
                                          $SubSubQuery = $this->db->query("SELECT * FROM tbl_menu WHERE menu_parent='" . $fRow1->id . "' ORDER BY menu_order ASC");
                                       }
                                    }

                                 ?>


                                    <?php if ($SubSubQuery != "") {
                                       if ($SubSubQuery->num_rows() > 0) {
                                    ?>

                                          <li class="dropdown dropdown-mega">
                                             <a class="dropdown-item dropdown-toggle" href="<?= $menuUrl; ?>">
                                                <?= $menuName; ?>
                                             </a>
                                             <ul class="dropdown-menu">
                                                <li>
                                                   <div class="dropdown-mega-content">
                                                      <div class="row">
                                                         <?php
                                                         foreach ($SubQuery->result() as $fRow1) {
                                                            $SubSubQuery = $this->db->query("SELECT * FROM tbl_menu WHERE menu_parent='" . $fRow1->id . "' ORDER BY menu_order ASC");
                                                            if ($fRow1->menu_type == 'Page') {
                                                               $fQuerySub1 = $this->db->query("SELECT * FROM tbl_page WHERE id= {$fRow1->page_id} ORDER BY id ASC");
                                                               foreach ($fQuerySub1->result() as $fRowSub1) {
                                                                  $menuName1 = $fRowSub1->page_name;
                                                                  $menuUrl1 = base_url($fRowSub1->page_slug) . '.html';
                                                               }
                                                            } else {
                                                               $menuName1 = $fRow1->menu_name;
                                                               $menuUrl1 = $fRow1->menu_url;
                                                            }

                                                         ?>
                                                            <div class="dd">
                                                               <a class="dropdown-item " href="<?= $menuUrl1; ?>"> <span class="dropdown-mega-sub-title">
                                                                     <img src="<?php echo base_url('assets/admin/uploads/' . $fRow1->menu_img) ?>" style="width:40px" /> <span style="color:black"> <?= $menuName1; ?> </span></span></a>
                                                               <ul class="dropdown-mega-sub-nav sub-nav-nav">
                                                                  <?php
                                                                  foreach ($SubSubQuery->result() as $fRow2) {
                                                                     if ($fRow2->menu_type == 'Page') {
                                                                        $fQuerySub2 = $this->db->query("SELECT * FROM tbl_page WHERE id= {$fRow2->page_id} ORDER BY id ASC");
                                                                        foreach ($fQuerySub2->result() as $fRowSub2) {
                                                                           $menuName2 = $fRowSub2->page_name;
                                                                           $menuUrl2 = base_url($fRowSub2->page_slug) . '.html';
                                                                        }
                                                                     } else {
                                                                        $menuName2 = $fRow2->menu_name;
                                                                        $menuUrl2 = $fRow2->menu_url;
                                                                     }
                                                                  ?>
                                                                     <li><a class="dropdown-item " href="<?= $menuUrl2; ?>"><?= $menuName2; ?></a></li>
                                                                  <?php } ?>

                                                               </ul>
                                                            </div>
                                                         <?php } ?>
                                                         <div class="dd">
                                                               <a class="dropdown-item " href="#"> <span class="dropdown-mega-sub-title">
                                                                     <img src="<?= base_url(); ?>assets/frontasset/images/cy.png" style="width:40px"> <span style="color:black"> Cyber Security </span></span></a>
                                                               <ul class="dropdown-mega-sub-nav sub-nav-nav">
                                                                  <li><a class="dropdown-item" href="<?= base_url('Home/syber'); ?>"> <span style="color:black" class=""> CM-as-a-Service</span>
                                                                        <p>Compliance-Management -As-A-Service</p>
                                                                     </a></li>
                                                                  <li><a class="dropdown-item" href="<?= base_url('Home/mdmservice'); ?>"> <span style="color:black" class=""> MDM-as-a-Service</span>
                                                                        <p>MDM-And-MTD-As-A-Service</p>
                                                                     </a></li>
                                                                  <li><a class="dropdown-item" href="<?= base_url('Home/patch'); ?>"> <span style="color:black" class=""> Patch Management</span>
                                                                        <p>Patch Management Services</p>
                                                                     </a></li>
                                                                  <li><a class="dropdown-item" href="<?= base_url('Home/sosservice'); ?>"> <span style="color:black" class=""> SOC-as-a-Service</span>
                                                                        <p>SIEM Based 24x7 SOC Monitoring </p>
                                                                     </a></li>
                                                                     
                                                               </ul>
                                                               
                                                </div>
                                                      </div>
                                                   </div>


                                                </li>
                                             </ul>
                                          </li>



                                       <?php } else { ?>


                                          
                                          <li class="dropdown">
                                             <a class="" href="<?= $menuUrl; ?>">
                                                <?= $menuName; ?>
                                             </a>
                                             <?php if ($SubQuery->num_rows() > 0) { ?>
                                                <ul class="dropdown-menu">
                                                   <?php
                                                   foreach ($SubQuery->result() as $fRow1) {
                                                      $SubSubQuery = $this->db->query("SELECT * FROM tbl_menu WHERE menu_parent='" . $fRow->id . "' ORDER BY menu_order ASC");
                                                      if ($fRow1->menu_type == 'Page') {
                                                         $fQuerySub1 = $this->db->query("SELECT * FROM tbl_page WHERE id= {$fRow1->page_id} ORDER BY id ASC");
                                                         foreach ($fQuerySub1->result() as $fRowSub1) {
                                                            $menuName1 = $fRowSub1->page_name;
                                                            $menuUrl1 = base_url($fRowSub1->page_slug) . '.html';
                                                         }
                                                      } else {
                                                         $menuName1 = $fRow1->menu_name;
                                                         $menuUrl1 = $fRow1->menu_url;
                                                      }

                                                   ?>
                                                      <li><a class="dropdown-item px-3" href="<?= $menuUrl1; ?>"><?= $menuName1; ?></a></li>
                                                   <?php } ?>
                                                </ul>
                                             <?php } ?>
                                          </li>
                                       <?php }
                                    } else {
                                       if ($menuName == 'Products') { ?>
                                          <li class="dropdown">
                                             <a class="" href="<?= $menuUrl; ?>">
                                                <?= $menuName; ?>
                                             </a>
                                             <ul class="dropdown-menu">
                                                <?php
                                                $sqlCat = $this->db->query("SELECT * FROM `tbl_category_prod` WHERE 1 ORDER BY `cat_order` ASC");
                                                foreach ($sqlCat->result() as $cat) {
                                                ?>
                                                   <li><a class="dropdown-item px-3" href="<?= base_url('product/' . $cat->category_slug . '.html') ?>"><?= $cat->category_name; ?></a></li>
                                                <?php } ?>
                                             <li><a class="dropdown-item px-3" href="<?= base_url('product/video_compression_solution') ?>">Video Compression Solution</a></li>

                                             </ul>
                                          </li>

                                       <?php } else {
                                       ?>
                                          <li class="dropdown">
                                             <a class="" href="<?= $menuUrl; ?>">
                                                <?= $menuName; ?>
                                             </a>
                                             <?php if ($SubQuery->num_rows() > 0) { ?>
                                                <ul class="dropdown-menu">
                                                   <?php
                                                   foreach ($SubQuery->result() as $fRow1) {
                                                      $SubSubQuery = $this->db->query("SELECT * FROM tbl_menu WHERE menu_parent='" . $fRow->id . "' ORDER BY menu_order ASC");
                                                      if ($fRow1->menu_type == 'Page') {
                                                         $fQuerySub1 = $this->db->query("SELECT * FROM tbl_page WHERE id= {$fRow1->page_id} ORDER BY id ASC");
                                                         foreach ($fQuerySub1->result() as $fRowSub1) {
                                                            $menuName1 = $fRowSub1->page_name;
                                                            $menuUrl1 = base_url($fRowSub1->page_slug) . '.html';
                                                         }
                                                      } else {
                                                         $menuName1 = $fRow1->menu_name;
                                                         $menuUrl1 = $fRow1->menu_url;
                                                      }

                                                   ?>
                                                      <li><a class="dropdown-item" href="<?= $menuUrl1; ?>"><?= $menuName1; ?></a></li>
                                                   <?php } ?>
                                                </ul>
                                             <?php } ?>
                                          </li>
                                    <?php }
                                    } ?>

                                 <?php } ?>

                              </ul>
                           </nav>
                        </div>

                        <button class="header-btn-collapse-nav ml-3" data-toggle="collapse" data-target=".header-nav-main nav">
                           <span class="hamburguer">
                              <span></span>
                              <span></span>
                              <span></span>
                           </span>
                           <span class="close">
                              <span></span>
                              <span></span>
                           </span>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>

      <style>
         @media(max-width:767px) {
            .header-top-container {
               max-width: 767px;
            }

            .header-columnokh77 {
               width: 140px !important;
            }

            .social-icons {
               font-size: 11px;
            }
         }

         /* .dropdown-mega-content {
            display: flex;
            flex-direction: column;
            width: 250px;
            /* Adjust width as needed */
         /* } */

         /* Hide submenu by default */
         /* .dropdown-mega-sub-nav {
            display: none;
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.5s ease-in-out, transform 0.5s ease-in-out;
         } */

         /* Show submenu when hovering over category */
         /* .dropdown-item:hover+.dropdown-mega-sub-nav,
         .dropdown-item:focus+.dropdown-mega-sub-nav,
         .dropdown-mega-sub-nav:hover {
            display: block;
            opacity: 1;
            transform: translateY(0);
         } */

         /* Animation: Submenu items appear one by one */
         /* .dropdown-mega-sub-nav li {
            opacity: 0;
            transform: translateX(-10px);
            transition: opacity 0.3s ease-in-out, transform 0.3s ease-in-out;
         } */

         /* Delay each item for sequential effect */
         /* .dropdown-mega-sub-nav li:nth-child(1) {
            transition-delay: 0.1s;
         }

         .dropdown-mega-sub-nav li:nth-child(2) {
            transition-delay: 0.2s;
         }

         .dropdown-mega-sub-nav li:nth-child(3) {
            transition-delay: 0.3s;
         }

         .dropdown-mega-sub-nav li:nth-child(4) {
            transition-delay: 0.4s;
         } */

         /* Show submenu items on hover */
         /* .dropdown-item:hover+.dropdown-mega-sub-nav li,
         .dropdown-item:focus+.dropdown-mega-sub-nav li,
         .dropdown-mega-sub-nav:hover li {
            opacity: 1;
            transform: translateX(0);
         } */

         #header .header-nav-main nav>ul>li.dropdown-mega>.dropdown-menu {
            background: #fff;
            left: 50% !important;
            right: auto !important;
            padding: 10px;
            width: 100% !important;
            max-width: 95vw;
            -webkit-transform: translate3d(-50%, 0, 0);
            transform: translate3d(-50%, 0, 0);
         }

         /* .dropdown-mega-sub-nav {
            position: absolute;
            left: 285px;
            width: 100%;
            z-index: 999;
            background: #fff;
            margin-left: 3px !important;
            padding: 10px !important;
            top: 1px;
            box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
         } */

         .item-border {
            border-bottom: 1px solid #ccc;
            padding: 10px !important;
         }

         .dropdown-mega-content {
            border-top: none;
         }

         .dropdown-mega-content {
            width: 100%;
         }

         .dropdown-menu {
            padding: 0 !important;
            border-radius: 0px !important;
         }

         /* .b-fix-column {
            flex-direction: column;
            align-items: flex-start !important;
            width: 300px;
         } */

         .dropdown-item p {
            margin-bottom: 0px;
            font-size: 13px;
         }

         /* .sub-nav-nav {
            overflow-y: scroll;
            height: 400px;
         } */
         .dd {
            width: 230px
         }


         @media(max-width:767px) {
            .dropdown-menu {
               position: absolute !important;
            }

            #header .header-nav-main nav>ul>li.dropdown-mega>.dropdown-menu {
               width: 100% !important;
            }

            .dropdown-mega-sub-nav {
               left: 0%
            }

            .shadoBtn {
               margin-top: 20px;
            }
         }

         @media(max-width:425px) {
            .smallBannerHeading {
               font-size: 16px;
            }
         }
      </style>